import React from 'react'

const ListOfPaitent = () => {
  return (
    <div>ListOfPaitent</div>
  )
}

export default ListOfPaitent