// import React, { useEffect, useState } from 'react'
// import { GetAllPatientTreatment, GetSinglePatientTreatment } from '../api/TreatmentApi'

// // 👇 import the function you already wrote
// import { formatFrequency } from '../utils/dawatimes'
// import { useNavigate, useParams } from 'react-router-dom';
// import { store } from '../redux/store';
// import { useDispatch } from 'react-redux';
// import { setLoading } from '../redux/LoadingSlice';
// import { IoClose } from 'react-icons/io5';

// const AllTreatments = () => {
//   const navigate = useNavigate()
//   const dispatch = useDispatch()
//   const { id } = useParams(); // 👈 get ID from route
//   const [treatments, setTreatments] = useState([])

//   const fetchData = async () => {
//       store.dispatch(setLoading(true));
//     try {
//       const data = id 
//       ? await GetSinglePatientTreatment(id)
//           : await GetAllPatientTreatment();

//         // If API for single returns an object, wrap it in array
//         console.log(" treatment data",data)
//         setTreatments(Array.isArray(data) ? data : [data]);
//       } catch (err) {
//         console.error(err);
//       } finally {
//           store.dispatch(setLoading(false));
//       }
//     };
//     useEffect(() => {

//     fetchData();
//   }, [id]);

//   return (
//     <div className="p-4">
//       <div className='flex gap-30 justify-between px-5'>
//         <h2 className="text-xl font-bold mb-4 text-center">All Treatments</h2>
//         <h2 className="text-2xl font-bold mb-4 text-center" onClick={()=>navigate(-1)}><IoClose/></h2>
//       </div>
//      {treatments?.length === 0 ? <>
//      <div>
//       <h2>No Any Treatmenst Founds</h2>
//       </div></> :  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
//         {treatments.map((treatment, index) => (
//           <div
//             key={index}
//             className="bg-white shadow-md rounded-lg p-4 hover:shadow-xl transition-all"
//           >
//             <h3 className="text-xl font-semibold mb-2 text-orange-600">Dr. {treatment.doctorName}</h3>

//             <div className="mb-2">
//               <p className="font-semibold text-gray-700">Patient:</p>
//               <p className="text-sm text-gray-600">
//                 {treatment?.patientId?.patientName || 'Unknown'} ({treatment?.patientId?.age} yrs)
//               </p>
//               <p className="text-sm text-gray-600">{treatment?.patientId?.phone}</p>
//             </div>

//             <div className="mb-2">
//               <p className="font-semibold text-gray-700">Problem:</p>
//               <p className="text-sm text-gray-600">{treatment.patinentProblem}</p>
//             </div>

//             {treatment.symptoms && treatment.symptoms.trim() !== '' && (
//               <div className="mb-2">
//                 <p className="font-semibold text-gray-700">Symptoms:</p>
//                 <p className="text-sm text-gray-600">{treatment.symptoms}</p>
//               </div>
//             )}

//             <div className="mb-2">
//               <p className="font-semibold text-gray-700">Medicines:</p>
//               {(treatment.medicines || []).map((med, medIndex) => (
//                 <div key={medIndex} className="bg-gray-50 p-2 rounded mt-1">
//                   <p className="text-sm font-medium text-black">
//                     {med.name} - {med.type} ({med.quantity})
//                   </p>
//                   <p className="text-xs text-gray-600">
//                     {formatFrequency(med.times)}
//                   </p>
//                 </div>
//               ))}
//             </div>

//             <p className="text-xs text-gray-500 mt-2">
//               Date: {treatment.date ? new Date(treatment.date).toLocaleDateString() : 'N/A'}
//             </p>
//           </div>
//         ))}
//       </div>}
//     </div>
//   )
// }

// export default AllTreatments





import React, { useEffect, useState } from 'react'
import { GetAllPatientTreatment, GetSinglePatientTreatment } from '../api/TreatmentApi'

// 👇 import the function you already wrote
import { formatFrequency } from '../utils/dawatimes'
import { useNavigate, useParams } from 'react-router-dom';
import { store } from '../redux/store';
import { useDispatch } from 'react-redux';
import { setLoading } from '../redux/LoadingSlice';
// icons
import {
  User,
  Phone,
  Stethoscope,
  AlertCircle,
  Pill,
  CalendarDays,
} from 'lucide-react';


const AllTreatments = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { id } = useParams(); // 👈 get ID from route
  const [treatments, setTreatments] = useState([])

  const fetchData = async () => {
      store.dispatch(setLoading(true));
    try {
      const data = id 
      ? await GetSinglePatientTreatment(id)
          : await GetAllPatientTreatment();

        // If API for single returns an object, wrap it in array
        console.log(" treatment data",data)
        setTreatments(Array.isArray(data) ? data : [data]);
      } catch (err) {
        console.error(err);
      } finally {
          store.dispatch(setLoading(false));
      }
    };
    useEffect(() => {

    fetchData();
  }, [id]);

  return (
    <div className="">
      <div className="flex items-center justify-between px-5 py-4 bg-gray-50 shadow-sm mb-4 rounded-md">
  <h2 className="text-xl sm:text-2xl text-blue-900 font-semibold tracking-wide">
    All Treatments
  </h2>
  <button
    onClick={() => navigate(-1)}
    className="text-sm sm:text-base text-white bg-blue-800 hover:bg-blue-900 px-4 py-2 rounded-md transition-all duration-200 font-medium shadow"
  >
    ← Back
  </button>
</div>

     {treatments?.length === 0 ? <>
     <div>
      <h2>No Any Treatmenst Founds</h2>
      </div></> :  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-2 lg:gap-4 px-5">
        {treatments.map((treatment, index) => (
       <div
       key={index}
       className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-all"
     >
       {/* Doctor Info */}
       <div className="lg:flex items-center justify-between mb-4">
         <div className="flex items-center gap-2">
           <Stethoscope className="text-blue-600 w-5 h-5" />
           <h3 className="text-lg font-semibold text-blue-900">
             {treatment.doctorName}
           </h3>
         </div>
         <div className="flex items-center gap-2 text-sm text-gray-500">
           <CalendarDays className="w-4 h-4" />
           {treatment.date
             ? new Date(treatment.date).toLocaleDateString()
             : 'N/A'}
         </div>
       </div>
     
       {/* Patient Info */}
       <div className="grid sm:grid-cols-2 gap-4 mb-4">
         <div className="flex items-start gap-2 text-sm text-gray-700">
           <User className="w-4 h-4 text-gray-500 mt-0.5" />
           <div>
             <p className="font-medium  max-w-[40px] ">
               {treatment?.patientId?.patientName || 'Unknown'}
             </p> 
             <p className="text-xs text-gray-500">
               {/* Id: {treatment?.patientId?.id || '-'} */}
               Age: {treatment?.patientId?.age || '-'}
             </p>
           </div>
         </div>
     
         <div className="flex items-start gap-2 text-sm text-gray-700">
           <Phone className="w-4 h-4 text-gray-500 mt-0.5" />
           <p className="font-medium">
             {treatment?.patientId?.phone || 'N/A'}
           </p>
         </div>
       </div>
     
       {/* Problem */}
       <div className="mb-3">
         <div className="flex items-center gap-2 text-gray-800 font-semibold text-sm mb-1">
           <AlertCircle className="w-4 h-4 text-red-500" />
           Problem
         </div>
         <p className="text-sm text-gray-600 ml-6">{treatment.patinentProblem}</p>
       </div>
     
       {/* Symptoms */}
       {treatment.symptoms?.trim() && (
         <div className="mb-3">
           <div className="flex items-center gap-2 text-gray-800 font-semibold text-sm mb-1">
             <AlertCircle className="w-4 h-4 text-yellow-500" />
             Symptoms
           </div>
           <p className="text-sm text-gray-600 ml-6">{treatment.symptoms}</p>
         </div>
       )}
     
       {/* Medicines */}
       <div className="mb-2">
         <div className="flex items-center gap-2 text-gray-800 font-semibold text-sm mb-1">
           <Pill className="w-4 h-4 text-green-600" />
           Medicines
         </div>
         <div className="ml-6 space-y-2">
           {(treatment.medicines || []).map((med, medIndex) => (
             <div
               key={medIndex}
               className="border border-gray-200 rounded-md p-2 bg-gray-50"
             >
               <div className="text-sm font-medium text-gray-800">
                 {med.name} - {med.type} ({med.quantity})
               </div>
               <div className="text-xs text-gray-500">
                 {formatFrequency(med.times)}
               </div>
             </div>
           ))}
         </div>
       </div>
     </div>
        ))}
      </div>}
    </div>
  )
}

export default AllTreatments
