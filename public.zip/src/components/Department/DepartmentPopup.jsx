import React, { useState, useEffect } from "react";
import { FaPlus, FaEdit } from "react-icons/fa";

const DepartmentPopup = ({ dept, onAdd, onEdit, isEdit }) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (dept) {
      setName(dept.name);
      setDescription(dept.description);
    }
  }, [dept]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEdit) {
      onEdit({ name, description });
    } else {
      onAdd({ name, description, status: true });
    }
    setOpen(false);
    setName("");
    setDescription("");
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className={`flex items-center gap-1 px-3 py-1 rounded text-white ${
          isEdit ? "bg-yellow-500" : "bg-[var(--main-color)]"
        }`}
      >
        {isEdit ? <FaEdit /> : <FaPlus />}
        {isEdit ? "" : "Add Department"}
      </button>

      {open && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-white p-5 rounded w-[90%] max-w-md">
            <h3 className="text-lg font-bold mb-3">
              {isEdit ? "Edit Department" : "Add Department"}
            </h3>
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <input
                type="text"
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="border p-2 rounded"
              />
              <textarea
                placeholder="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                className="border p-2 rounded"
              />
              <div className="flex justify-end gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="px-3 py-1 border rounded"
                >
                  Cancel
                </button>
                <button type="submit" className="px-3 py-1 bg-[var(--main-color)] text-white rounded">
                  {isEdit ? "Update" : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default DepartmentPopup;
