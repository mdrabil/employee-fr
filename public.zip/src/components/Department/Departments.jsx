import React, { useState, useMemo } from "react";
import { FaEdit, FaTrash } from "react-icons/fa";
import DepartmentPopup from "./DepartmentPopup";
import Pagination from "../Pagination/Pagination";

const Departments = () => {
  const [departments, setDepartments] = useState([
    { id: 1, name: "HR", description: "Handles HR tasks", status: true },
    { id: 2, name: "IT", description: "Manages IT systems", status: false },
    { id: 3, name: "Finance", description: "Handles accounts", status: true },
    { id: 4, name: "Marketing", description: "Promotes products", status: true },
  ]);

  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Filtered and paginated
  const filteredDepartments = useMemo(() => {
    return departments.filter((d) =>
      d.name.toLowerCase().includes(filterText.toLowerCase())
    );
  }, [departments, filterText]);

  const totalPages = Math.ceil(filteredDepartments.length / itemsPerPage);
  const paginatedDepartments = filteredDepartments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // CRUD actions
  const handleDelete = (id) => setDepartments(departments.filter((d) => d.id !== id));
  const handleAdd = (newDept) => setDepartments([...departments, { ...newDept, id: Date.now() }]);
  const handleEdit = (id, updatedDept) =>
    setDepartments(departments.map((d) => (d.id === id ? { ...d, ...updatedDept } : d)));
  const toggleStatus = (id) =>
    setDepartments(
      departments.map((d) => (d.id === id ? { ...d, status: !d.status } : d))
    );

  return (
    <div className=" bg-[var(--bg-color)] min-h-screen">
      <h2 className="text-2xl font-bold text-[var(--main-color)] mb-4">
        Department {departments.length}
      </h2>

      <div className="flex flex-wrap justify-between gap-3 mb-4 items-start">
        <input
          type="text"
          placeholder="Search by name..."
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          className="px-3 py-2 border rounded border-[var(--border-main)]"
        />
        <DepartmentPopup onAdd={handleAdd} />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-[var(--secondary-bg-color)] text-left ">
              <th className="p-2 border-b">Name</th>
              <th className="p-2 border-b">Description</th>
              <th className="p-2 border-b">Status</th>
              <th className="p-2 border-b text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {paginatedDepartments.map((dept) => (
              <tr key={dept.id} className="border-b hover:bg-[var(--bg-color)] transition">
                <td className="p-2">{dept.name}</td>
                <td className="p-2">{dept.description}</td>
                <td className="p-2">
                  <label className="inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={dept.status}
                      onChange={() => toggleStatus(dept.id)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-300 rounded-full peer peer-checked:bg-[var(--main-color)] transition"></div>
                  </label>
                </td>
                <td className="p-2 flex gap-2 justify-end">
                  <DepartmentPopup
                    dept={dept}
                    onEdit={(updatedDept) => handleEdit(dept.id, updatedDept)}
                    isEdit
                  />
                  <button
                    onClick={() => handleDelete(dept.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))}
            {paginatedDepartments.length === 0 && (
              <tr>
                <td colSpan="4" className="text-center p-4 text-[var(--text-color)]">
                  No departments found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
<div className="w-full text-end">
  
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
</div>
    </div>
  );
};

export default Departments;
