import React from "react";

const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  return (
    <div className="flex justify-end gap-2 mt-4">
      <button
        disabled={currentPage === 1}
        onClick={() => onPageChange(currentPage - 1)}
        className="px-3 py-1 rounded border border-[var(--border-main)] disabled:opacity-50"
      >
        Prev
      </button>
      {[...Array(totalPages)].map((_, idx) => (
        <button
          key={idx}
          onClick={() => onPageChange(idx + 1)}
          className={`px-3 py-1 rounded border border-[var(--border-main)] ${
            currentPage === idx + 1
              ? "bg-[var(--main-color)] text-white"
              : "bg-white text-[var(--text-color)]"
          }`}
        >
          {idx + 1}
        </button>
      ))}
      <button
        disabled={currentPage === totalPages}
        onClick={() => onPageChange(currentPage + 1)}
        className="px-3 py-1 rounded border border-[var(--border-main)] disabled:opacity-50"
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
